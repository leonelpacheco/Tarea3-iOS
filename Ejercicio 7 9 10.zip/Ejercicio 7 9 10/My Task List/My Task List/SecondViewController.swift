//
//  SecondViewController.swift
//  My Task List
//
//  Created by Leonel Pacehco on 6/14/15.
//  Copyright (c) 2015 Leonel Pacheco. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var desc: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
 
    func textFieldShouldReturn(textField: UITextField) -> Bool {
       textField.resignFirstResponder()
        return true
    }

    @IBAction func btnAddTask(sender: AnyObject) {
        taskMgr.addTask(name.text, desc: desc.text)
        self.view.endEditing(true)
        name.text = ""
        desc.text = ""
        self.tabBarController?.selectedIndex = 0
    }
}

